﻿using Entities;
using System.Collections.Generic;
using ApplicationCoreInterface.Services;
using InfrastructureInterface.Data.Repositories;
using System;
using System.Dynamic;
using Exceptions;

namespace ApplicationCore.Services
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _repository;
        private readonly ILodgingService _lodgingService;
        private readonly IPriceCalculatorService _priceCalculatorService;

        private const string InvalidDateErrorMessage =
            "Error, the Check-out date must be greater than the Check-in date.";
        private const string ReviewAlreadyExistErrorMessage =
            "A review has already been registered for this booking.";

        public BookingService(IBookingRepository repository, ILodgingService lodgingService,
            IPriceCalculatorService priceCalculatorService)
        {
            _repository = repository;
            _lodgingService = lodgingService;
            _priceCalculatorService = priceCalculatorService;
        }

        public Booking Add(Booking booking)
        {
            booking.Lodging = _lodgingService.GetById(booking.Lodging.Id);
            booking.Code = Guid.NewGuid().ToString();
            booking.Price = GetPrice(booking);

            ValidateBooking(booking);

            UpdateLodgingCapacity(booking);

            return _repository.Add(booking);
        }

        private double GetPrice(Booking booking)
        {
            var totalDays = (int) (booking.CheckOutDate - booking.CheckInDate).TotalDays;
            var calculatedPrice =
                _priceCalculatorService.CalculatePrice(booking.NumberOfGuests, booking.Lodging.CostPerNight) *
                totalDays;
            return calculatedPrice;
        }

        private void ValidateBooking(Booking booking)
        {
            ValidateDates(booking.CheckInDate, booking.CheckOutDate);
            ValidateLodgingCapacity(booking);
        }

        private void ValidateDates(DateTime checkInDate, DateTime checkOutDate)
        {
            if (checkInDate >= checkOutDate)
            {
                throw new InvalidAttributeValuesException(InvalidDateErrorMessage);
            }
        }

        private void ValidateLodgingCapacity(Booking booking)
        {
            var lodging = booking.Lodging;
            if (lodging.MaximumSize < (lodging.CurrentlyOccupiedPlaces + booking.TotalNumberOfGuests))
            {
                throw new InvalidAttributeValuesException("There is no place available for " +
                                                          booking.TotalNumberOfGuests +
                                                          " people");
            }
        }

        private void UpdateLodgingCapacity(Booking booking)
        {
            Lodging lodging = booking.Lodging;
            lodging.CurrentlyOccupiedPlaces += booking.TotalNumberOfGuests;
            _lodgingService.Update(lodging);
        }

        public IEnumerable<Booking> GetAll()
        {
            return _repository.GetAll();
        }

        public Booking Get(string bookingCode)
        {
            return _repository.Get(bookingCode);
        }

        public void UpdateState(Booking booking)
        {
            _repository.UpdateState(booking);
        }
        
        public void UpdateReview(Booking updateBooking)
        {
            var booking = Get(updateBooking.Code);
            if (booking.TouristReview != null)
            {
                throw new ObjectAlreadyExistException(ReviewAlreadyExistErrorMessage);
            }

            booking.TouristReview = updateBooking.TouristReview;
            UpdateLodgingPoints(booking);
            _repository.UpdateReview(booking);
        }

        private void UpdateLodgingPoints(Booking booking)
        {
            Lodging lodging = booking.Lodging;
            lodging.NumberOfStars = CalculateLodging(lodging, booking.TouristReview.NumberOfPoints);
            lodging.ReviewsCount++;
            _lodgingService.Update(lodging);
        }

        private int CalculateLodging(Lodging lodging, int points)
        {
            if (lodging.ReviewsCount > 0)
            {
                return ((lodging.NumberOfStars * lodging.ReviewsCount) + points) / (lodging.ReviewsCount + 1);
            }

            return points;
        }
    }
}