﻿namespace Web.Models.Session
{
    public class LogoutOutModel
    {
        public string Message { get; set; } = "Logout successfully";
    }
}
